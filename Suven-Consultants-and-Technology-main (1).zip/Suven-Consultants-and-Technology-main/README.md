# Suven-Consultants-and-Technology
## Online Coding Internship

### 1.Sentiment Analysis (ML) Project

#### Analysing Movie Reviews using Sentiment analysis

This project focuses on Text pre-processing and Normalization using NLP, Sentiment analysis using the Unsupervised Lexicon-based models and classifying sentiment using Traditional supervised models.

Project Blog: https://gayathri1462.medium.com/analysing-movie-reviews-using-sentimental-analysis-77e28e463b1b

### 2.Data Analytics using Python Coding Projects
#### (i) Performing Analysis of Meteorological Data

The main objective is to perform data cleaning, perform analysis for testing the Influences of Global Warming on temperature and humidity, and finally put forth a conclusion.

Project Blog: https://gayathri1462.medium.com/performing-analysis-of-meteorological-data-9db091151261

#### (ii) Recognizing Handwritten Digits with Scikit-Learn

The primary aim of this project involves predicting a numeric value, and then reading and interpreting an image that uses a handwritten font.
we will have an estimator with the task of learning through a fit() function, and once it has reached a degree of predictive capability (a model sufficiently valid), it will produce a prediction with the predict() function. 

Project Blog: https://gayathri1462.medium.com/recognizing-handwritten-digits-with-scikit-learn-157fd6073857
